import os, stat

def main():
	f = open(__path__ + "config" , 'r+')
	text = f.read()
	
	text = text.replace('{%blenderplayer%}', player)
	text = text.replace('{%gamefile%}', blend)
	f.seek(0)
	f.write(text)
    
    ngame = game
	if not game: ngame = "launcher"
	os.rename(__path__ + "simple.exe", __path__ + ngame + '.exe')

if __name__ == '__main__':
    main()
