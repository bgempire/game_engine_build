import os, stat

def main():
    f = open(__path__ + "config" , 'r+')
    text = f.read()
    
    text = text.replace('{%blenderplayer%}', player)
    text = text.replace('{%gamefile%}', blend)
    
    f.seek(0)
    f.write(text)
    
    ngame = game
    if not ngame: ngame = "launcher"
    os.rename(__path__ + "simple", __path__ + ngame)
    st = os.stat(__path__ + ngame)
    os.chmod(__path__ + ngame, st.st_mode | stat.S_IEXEC)
    
if __name__ == '__main__':
    main()
